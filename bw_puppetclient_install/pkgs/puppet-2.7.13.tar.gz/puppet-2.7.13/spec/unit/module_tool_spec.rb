require 'spec_helper'
require 'puppet/module_tool'

describe Puppet::Module::Tool do
end
